(cat /home/mario/ecommerce/vendas/backup/*.txt; printf "\n") >> /home/mario/ecommerce/relatorio_final.txt
