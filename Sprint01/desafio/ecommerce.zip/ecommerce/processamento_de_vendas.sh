if [ ! -d "/home/mario/ecommerce/vendas" ]; then   mkdir -p "/home/mario/ecommerce/vendas"; fi
cp -u /home/mario/ecommerce/dados_de_vendas.csv /home/mario/ecommerce/vendas
cd vendas
if [ ! -d "/home/mario/ecommerce/vendas/backup" ]; then   mkdir -p "/home/mario/ecommerce/vendas/backup"; fi
cp -u /home/mario/ecommerce/dados_de_vendas.csv /home/mario/ecommerce/vendas/backup
cd backup
mv /home/mario/ecommerce/vendas/dados_de_vendas.csv /home/mario/ecommerce/vendas/dados_de_vendas-$(date +%Y%m%d).csv
mv /home/mario/ecommerce/vendas/backup/dados_de_vendas* /home/mario/ecommerce/vendas/backup/backup-dados-$(date +%Y%m%d_%H%M).csv
OUTPUT_FILE="/home/mario/ecommerce/vendas/backup/relatorio_$(date +"%Y%m%d_%H%M%S").txt"
touch "$OUTPUT_FILE"
date +"%Y/%m/%d %H:%M" > "$OUTPUT_FILE"
sed -n '2p' /home/mario/ecommerce/dados_de_vendas.csv | cut -d',' -f5 >> "$OUTPUT_FILE"
sed -n '67p' /home/mario/ecommerce/dados_de_vendas.csv | cut -d',' -f5 >> "$OUTPUT_FILE"
tail -n +2 /home/mario/ecommerce/dados_de_vendas.csv | cut -d',' -f2 | sort | uniq | wc -l >> "$OUTPUT_FILE"
tail -n +2 /home/mario/ecommerce/dados_de_vendas.csv | head -n 11 /home/mario/ecommerce/dados_de_vendas.csv >> "$OUTPUT_FILE"
echo >> "$OUTPUT_FILE"
gzip /home/mario/ecommerce/vendas/backup/backup-dados*
rm -f /home/mario/ecommerce/vendas/backup/*.csv
cd ..
rm -f /home/mario/ecommerce/vendas/dados_de_vendas*
